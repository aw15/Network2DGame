#pragma once
#include"stdafx.h"

#define PI 3.141592
#define TRI_NUM 15




class Effect
{
	float radius=1;
	Vector3 rotation = { 0,0,0 };
	Vector3 color;
	Vector3 position;

public:
	bool end = false;
	Effect(Vector3 position,Vector3 color);
	void Render();
	void DrawTriangle();

};