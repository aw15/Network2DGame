#include "stdafx.h"
#include "Stage.h"




bool Stage::CollisionCheck( Vector3 & compare)
{
	for (auto poly : stage[activeStageNumber - 1])
	{
		if (poly->minPoint.x > compare.x || poly->maxPoint.x < compare.x)
			continue;
		else if (poly->minPoint.y > compare.y || poly->maxPoint.y < compare.y)
			continue;
		else if (poly->minPoint.z > compare.z || poly->maxPoint.z < compare.z)
			continue;
		else
		{
			int randomColor = rand() % 4;;
			Effect* effect;
			switch (activeStageNumber)
			{
			case 1:
				poly->ChangeColor(stage_1_color[randomColor]);
				effect = new Effect(compare, stage_1_color[randomColor]);
				break;
			case 2:
				poly->ChangeColor(stage_2_color[randomColor]);
				effect = new Effect(compare, stage_2_color[randomColor]);
				break;
			case 3:
				poly->ChangeColor(stage_3_color[randomColor]);
				effect = new Effect(compare, stage_3_color[randomColor]);
				break;
			case 4:
				poly->ChangeColor(stage_4_color[randomColor]);
				effect = new Effect(compare, stage_4_color[randomColor]);
				break;
			case 5:
				poly->ChangeColor(stage_5_color[randomColor]);
				effect = new Effect(compare, stage_5_color[randomColor]);
				break;
			case 6:
				poly->ChangeColor(stage_6_color[randomColor]);
				effect = new Effect(compare, stage_6_color[randomColor]);
				break;
			case 7:
				poly->ChangeColor(stage_7_color[randomColor]);
				effect = new Effect(compare, stage_7_color[randomColor]);
				break;
			case 8:
				poly->ChangeColor(stage_8_color[randomColor]);
				effect = new Effect(compare, stage_8_color[randomColor]);
				break;
			}
			
			
			effectList.push_back(effect);
			return true;
		}
	}
	return false;
}

Stage::Stage()
{
	Pyramid* temp[10];
	//--------------�������� ����-----------------
	temp[0] = new Pyramid;
	temp[1] = new Pyramid;
	temp[2] = new Pyramid;
	temp[3]= new Pyramid;
	temp[0]->RotateZ(0);
	temp[0]->Move({ 0,100,0 });
	temp[1]->RotateZ(90);
	temp[1]->Move({ -100,0,0 });
	temp[2]->RotateZ(180);
	temp[2]->Move({ 0,0 - 100,0 });
	temp[3]->RotateZ(270);
	temp[3]->Move({ 100,0,0 });
	for (int i = 0; i < 4; i++)
	{
		temp[i]->SetCollider();
		stage[0].push_back(temp[i]);
	}
	background[0] = bind(Draw_Background1);
	//---------------------2--------------------------
	temp[0] = new Pyramid;
	temp[1] = new Pyramid;
	temp[2] = new Pyramid;
	temp[3] = new Pyramid;
	temp[4] = new Pyramid;
	temp[0]->Move({ 100,0,0 });
	temp[1]->Move({ -100,0,0 });
	temp[2]->Move({ 100, -100,0 });
	temp[2]->RotateZ(90);
	temp[3]->Move({ -100,-100,0 });
	temp[3]->RotateZ(270);
	for (int i = 0; i < 5; i++)
	{
		temp[i]->SetCollider();
		stage[1].push_back(temp[i]);
	}
	background[1] = bind(Draw_Background2);
	
}


Stage::~Stage()
{
}

void Stage::SetStage(int stage)
{
	activeStageNumber = stage;
}

void Stage::Update()
{

	clock_t currentTime = clock();
	bool collide = false;
	totalTime += (currentTime - prevTime);
	prevTime = currentTime;



	

	for (auto iter = player.bulletList.begin(); iter != player.bulletList.end();)
	{
		auto bullet = *iter;
		if (CollisionCheck(bullet->position))
		{
			iter = player.bulletList.erase(iter);
		}
		else
			iter++;
	}

	player.Update();
}

void Stage::HandleEvent(unsigned char key)
{
	if (key == ' ')
	{
		if (totalTime / CLOCKS_PER_SEC > 0.2)
		{
			player.Shoot();
			totalTime = 0;
		}
	}
}

void Stage::Render()
{
	glPushMatrix();
	glLoadIdentity();
	background[activeStageNumber - 1]();
	glPopMatrix();
	player.Render();
	for (auto poly : stage[activeStageNumber - 1])
	{
		poly->Render();
		//LOG_3("POINT",poly->position.x ,poly->position.y ,poly->position.z );
	}
	for (auto iter = effectList.begin(); iter != effectList.end();)
	{
		auto effect = *iter;
		effect->Render();
		if (effect->end)
			iter = effectList.erase(iter);
		else
			iter++;
	}
}


float RGB_c(float num)  //RGB�� -> glcolor���·� ��ȯ
{
	num = num / 255;

	return num;
}

Vector3 background_Verticies[4] = { { 800.0, 800.0, -300.0 },{ -800.0, 800.0, -300.0 },{ -800.0, -800.0, -300.0 },{ 800.0, -800.0, -300.0 } };

void Draw_Background1() {

	glBegin(GL_QUADS);
	glColor3f(RGB_c(92), RGB_c(209), RGB_c(229));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(92), RGB_c(209), RGB_c(229));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(212), RGB_c(244), RGB_c(250));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(212), RGB_c(244), RGB_c(250));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();

}

void Draw_Background2() {
	glBegin(GL_QUADS);
	glColor3f(RGB_c(206), RGB_c(0), RGB_c(35));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(206), RGB_c(0), RGB_c(35));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(255), RGB_c(167), RGB_c(167));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(255), RGB_c(167), RGB_c(167));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}
void Draw_Background3() {
	glBegin(GL_QUADS);
	glColor3f(RGB_c(31), RGB_c(25), RGB_c(13));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(31), RGB_c(25), RGB_c(13));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(93), RGB_c(93), RGB_c(93));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(93), RGB_c(93), RGB_c(93));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}
void Draw_Background4() {
	glBegin(GL_QUADS);
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glVertex3f(600.0, 600.0, -200.0);//1
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glVertex3f(-600.0, 600.0, -200.0);//2
	glColor3f(RGB_c(18), RGB_c(69), RGB_c(171));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(18), RGB_c(69), RGB_c(171));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}
void Draw_Background5() {
	glBegin(GL_QUADS);
	glColor3f(RGB_c(183), RGB_c(240), RGB_c(177));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(183), RGB_c(240), RGB_c(177));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(206), RGB_c(242), RGB_c(121));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(206), RGB_c(242), RGB_c(121));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}
void Draw_Background6() {

	glBegin(GL_QUADS);
	glColor3f(RGB_c(255), RGB_c(178), RGB_c(217));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(255), RGB_c(178), RGB_c(217));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(255), RGB_c(217), RGB_c(236));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(255), RGB_c(217), RGB_c(236));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}
void Draw_Background7() {
	glBegin(GL_QUADS);
	glColor3f(RGB_c(206), RGB_c(0), RGB_c(35));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(206), RGB_c(0), RGB_c(35));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(255), RGB_c(167), RGB_c(167));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(255), RGB_c(167), RGB_c(167));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}
void Draw_Background8() {
	glBegin(GL_QUADS);
	glColor3f(RGB_c(21), RGB_c(18), RGB_c(120));
	glVertex3f(background_Verticies[0].x, background_Verticies[0].y, background_Verticies[0].z);//1
	glColor3f(RGB_c(21), RGB_c(18), RGB_c(120));
	glVertex3f(background_Verticies[1].x, background_Verticies[1].y, background_Verticies[1].z);//1
	glColor3f(RGB_c(18), RGB_c(69), RGB_c(171));
	glVertex3f(background_Verticies[2].x, background_Verticies[2].y, background_Verticies[2].z);//1
	glColor3f(RGB_c(18), RGB_c(69), RGB_c(171));
	glVertex3f(background_Verticies[3].x, background_Verticies[3].y, background_Verticies[3].z);//1
	glEnd();
}