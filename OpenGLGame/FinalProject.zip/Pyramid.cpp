#include "stdafx.h"
#include "Pyramid.h"


Pyramid::Pyramid()
{
}


void Pyramid::Render()
{

	glColor3ub( color.x,color.y,color.z);
	glPushMatrix();
	{
		//glRotatef(zDegree, 0, 0, 1);
		zDegree += 10;

		glPushMatrix();
		{
			glTranslatef(position.x, position.y, position.z);
			glRotatef(rotation.x, 1, 0, 0);
			glRotatef(rotation.y, 0, 1, 0);
			glRotatef(rotation.z, 0, 0, 1);
			glBegin(GL_POLYGON);
			//-----��-----
			glNormal3f(0, 1, 0);
			for (int i = 0; i < 4; i++)
			{
				glVertex3f(verticies[i].x, verticies[i].y, verticies[i].z);
			}
			glEnd();
			glBegin(GL_TRIANGLES);
			//----����------
			glNormal3f(0, 1, 0);
			for (int i = 0; i < 2; i++)
			{
				glVertex3f(verticies[i].x, verticies[i].y, verticies[i].z);
			}
			glVertex3f(verticies[4].x, verticies[4].y, verticies[4].z);
			//----������------
			glNormal3f(0, 1, 0);
			for (int i = 0; i < 2; i++)
			{
				glVertex3f(verticies[i + 2].x, verticies[i + 2].y, verticies[i + 2].z);
			}
			glVertex3f(verticies[4].x, verticies[4].y, verticies[4].z);
			////---����------
			glNormal3f(0, 1, 0);
			for (int i = 0; i < 2; i++)
			{
				glVertex3f(verticies[(i + 3) % 4].x, verticies[(i + 3) % 4].y, verticies[(i + 3) % 4].z);
			}
			glVertex3f(verticies[4].x, verticies[4].y, verticies[4].z);
			////------------����------------------
			glNormal3f(0, 1, 0);
			for (int i = 0; i < 2; i++)
			{
				glVertex3f(verticies[i + 1].x, verticies[i + 1].y, verticies[i + 1].z);
			}
			glVertex3f(verticies[4].x, verticies[4].y, verticies[4].z);
			glEnd();
		}
		glPopMatrix();
	}
	glPopMatrix();
}

void Pyramid::Move(Vector3 direction)
{
	position = position + direction;
}

void Pyramid::ChangeColor(Vector3 param)
{
	color.x = param.x;
	color.y = param.y;
	color.z = param.z;
}


void Pyramid::SetCollider()
{
	minPoint.x = position.x - 30;
	minPoint.y = position.y - 30;
	minPoint.z = position.z - 30;
	maxPoint.x = position.x + 30;
	maxPoint.y = position.y + 30;
	maxPoint.z = position.z + 30;
}



void Pyramid::RotateZ(int degree)
{
	rotation.z += degree;
}

void Pyramid::RotateY(int degree)
{
	rotation.y += degree;
}

void Pyramid::RotateX(int degree)
{
	rotation.x += degree;
}
