#pragma once
#include"Pyramid.h"
#include"Player.h"
#include"Bullet.h"
#include"effect.h"
void Draw_Background1();
void Draw_Background2();
void Draw_Background3();
void Draw_Background4();
void Draw_Background5();
void Draw_Background6();
void Draw_Background7();
void Draw_Background8();


class Stage
{
public:
	Stage();
	~Stage();
	void SetStage(int stage);
	bool CollisionCheck(Vector3 & compare);
	void Render();
	void Update();
	void HandleEvent(unsigned char key);

private:
	vector<Pyramid*> stage[8];
	Vector3 stage_1_color[4] = { {203, 255, 245}, {232, 119, 171}, {113, 182, 255},{244,255,246 }};
	Vector3 stage_2_color[4] = { { 219,205,43 },{ 196,184,100 },{ 166,163,147 },{ 42,196,58 } };
	Vector3 stage_3_color[4] = { {212,185,165 }, { 219,232,205 }, { 216,255,223 },{ 255,255,161 }};
	Vector3 stage_4_color[4] = { {219,205,43 }, { 167,100,196 }, { 150,166,147 }, { 244,255,246 }};
	Vector3 stage_5_color[4] = { { 240,240,246 },{ 239,202,110 },{ 214,195,192 },{ 9,181,154 } };
	Vector3 stage_6_color[4] = { { 255,205,18 },{ 183,240,177 },{ 250,244,192 } ,{ 255,255,255 } };
	Vector3 stage_7_color[4] = { { 219,205,43 },{ 196,184,100 } ,{ 166,163,147 },{ 42,1963,58 } };
	Vector3 stage_8_color[4] = { { 219,205,43 },{ 167,100,196 },{ 150,166,147 },{ 246,246,246 } };

	vector<Effect*> effectList;
	Player player;
	int activeStageNumber = 1;
	clock_t totalTime = 50000;
	clock_t prevTime;
	function <void()> background[8] = {};
};


