#include "stdafx.h"
#include "effect.h"





Effect::Effect(Vector3 position, Vector3 color)
{
	srand(time(NULL));
	this->position = position;
	this->color = color;
}

void Effect::Render()
{
	glColor3ub(color.x, color.y, color.z);
	glPushMatrix();
	glTranslatef(position.x, position.y, position.z);
	for (int i = 0; i < 360; i+=3)
	{
		glPushMatrix();
		glTranslatef(cos(i*RADIAN)*radius, sin(i*RADIAN)*radius, 0);
		glRotatef(rotation.y, 0, 1,0);
		DrawTriangle();
		glPopMatrix();
		glPushMatrix();
		glRotatef(30, 0, 1, 0);
		glTranslatef(cos(i*RADIAN)*radius, sin(i*RADIAN)*radius, 0);
		glRotatef(rotation.y, 0, 1, 0);
		DrawTriangle();
		glPopMatrix();
		glPushMatrix();
		glRotatef(60, 0, 1, 0);
		glTranslatef(cos(i*RADIAN)*radius, sin(i*RADIAN)*radius, 0);
		glRotatef(rotation.y, 0, 1, 0);
		DrawTriangle();
		glPopMatrix();
		glPushMatrix();
		glRotatef(90, 0, 1, 0);
		glTranslatef(cos(i*RADIAN)*radius, sin(i*RADIAN)*radius, 0);
		glRotatef(rotation.y, 0, 1, 0);
		DrawTriangle();
		glPopMatrix();
		glPushMatrix();
		glRotatef(120, 0, 1, 0);
		glTranslatef(cos(i*RADIAN)*radius, sin(i*RADIAN)*radius, 0);
		glRotatef(rotation.y, 0, 1, 0);
		DrawTriangle();
		glPopMatrix();
		glPushMatrix();
		glRotatef(150, 0, 1, 0);
		glTranslatef(cos(i*RADIAN)*radius, sin(i*RADIAN)*radius, 0);
		glRotatef(rotation.y, 0, 1, 0);
		DrawTriangle();
		glPopMatrix();

	}
	glPopMatrix();
	radius += 0.3;
	rotation.y += 10;
	if (radius > 20)
		end = true;

}
void Effect::DrawTriangle() {

	glPushMatrix();
	glBegin(GL_POLYGON); {
		//�ظ�
		glNormal3f(0.0, 1, 0.0);
		glVertex3f(-1, 0, 1);
		glVertex3f(1, 0, 1);
		glVertex3f(1, 0, -1);
		glVertex3f(-1, 0, -1);
	}
	glEnd();
	glBegin(GL_TRIANGLES); {
		//��1
		glNormal3f(-1.0, 0, 0.0);
		glVertex3f(-1, 0, -1);
		glVertex3f(-1, 0, 1);
		glVertex3f(0, 3, 0); //�ﰢ�� ����
	}
	glEnd();

	glBegin(GL_TRIANGLES); {
		//��2
		glNormal3f(0.0, 0, 1.0);
		glVertex3f(-1, 0, 1);
		glVertex3f(1, 0, 1);
		glVertex3f(0, 3, 0);
	}
	glEnd();

	glBegin(GL_TRIANGLES); {
		//��3
		glNormal3f(1.0, 0, 0.0);
		glVertex3f(1, 0, 1);
		glVertex3f(1, 0, -1);
		glVertex3f(0, 3, 0);
	}
	glEnd();

	glBegin(GL_TRIANGLES); {
		//��4
		glNormal3f(0.0, 0, -1.0);
		glVertex3f(1, 0, -1);
		glVertex3f(-1, 0, -1);
		glVertex3f(0, 3, 0);
	}
	glEnd();
	glPopMatrix();

}

