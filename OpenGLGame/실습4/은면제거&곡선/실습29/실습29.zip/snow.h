#pragma once
class snow
{
public:
	snow();
	~snow();
	void Draw();
	void Update();
	Vector3 position;
};

