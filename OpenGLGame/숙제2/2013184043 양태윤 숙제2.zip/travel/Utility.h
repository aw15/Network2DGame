#pragma once
Vector3 _getBezier(const Vector3 v1, const Vector3 v2, const Vector3 v3, const Vector3 v4, const float fDetail);
